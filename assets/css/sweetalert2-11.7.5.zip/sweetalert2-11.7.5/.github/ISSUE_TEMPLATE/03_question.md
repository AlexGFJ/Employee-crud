---
name: Question
about: Ask a question
labels:
---

Please post your question to StackOverflow: https://stackoverflow.com/questions/ask
Make sure to add the `sweetalert2` tag to the question.

Thank you.
